from django.shortcuts import render, redirect
from django.http import HttpResponse
'''HttpResponse is used to directly display data on browser'''

def home(request):
    return render(request, 'index.html')
def about(request):
    return render(request, 'about.html')
def book(request):
    return render(request, 'book.html')
def menu(request):
    return render(request, 'menu.html')

def form(request):
    # Handle GET query parameters (e.g., /form?name=...&age=...&city=...)
    sname = request.GET.get('name')
    sage = request.GET.get('age')
    scity = request.GET.get('city')
    if sname or sage or scity:
        return HttpResponse(f"""
        <h2>GET Query Parameters Received</h2>
        <p><strong>Name:</strong> {sname}</p>
        <p><strong>Age:</strong> {sage}</p>
        <p><strong>City:</strong> {scity}</p>
        """)

    if request.method == 'POST':
        # it take data from form
        name = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        subject = request.POST.get('subject')
        interests = request.POST.getlist('interests')
        interest_level = request.POST.get('interest_level')

        # Response of strings
        http_response = f"""
        <h2>User Registration Details</h2>
        <p><strong>Username:</strong> {name}</p>
        <p><strong>Email:</strong> {email}</p>
        <p><strong>Password:</strong> {password}</p>
        <p><strong>Confirm Password:</strong> {confirm_password}</p>
        <p><strong>Subject:</strong> {subject}</p>
        <p><strong>Interests:</strong> {', '.join(interests) if interests else 'None'}</p>
        <p><strong>Interest Level (1–10):</strong> {interest_level}</p>
        """
        return HttpResponse(http_response)

    return render(request, 'form.html')

def response(request):
    context = {
        'fname': 'Sheikh',
        'City': 'bwp',
        'lname': 'Ali',
        'hobbies': ['khelna', 'fazol time', ' khana', 'sona']
    }
    return render(request, 'response.html', context)


def setsession(request):
    request.session['username'] = 'mahram raz'
    request.session['email'] = 'mahram@example.com'
    return HttpResponse("Session data has been set.")



def getsession(request):
    username = request.session.get('username', 'Guest')
    email = request.session.get('email', 'Not set')
    return HttpResponse(f"Username: {username}<br>Email: {email}")


def clear_session(request):
    request.session.flush()
    return HttpResponse("Session data has been cleared.")

def flush_session(request):
    request.session.flush()
    return HttpResponse("All session data has been flushed.")







#Assignment Views

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username == password:
            request.session['username'] = username
            return redirect('dashboard')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials!'})
    
    if 'username' in request.session:
        return redirect('dashboard')
    
    return render(request, 'login.html')


def dashboard_view(request):
    if 'username' not in request.session:
        return redirect('login')
    
    username = request.session['username']
    return render(request, 'dashboard.html', {'username': username})


def logout_view(request):
    request.session.flush()  
    return redirect('login')



"""
1.session for single variable (previous value replace with new value)

2.how to manage session in lists
request.session.modified = True ()



"""
