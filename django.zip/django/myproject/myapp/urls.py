from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='index'),
    path('about/', views.about, name='about'),
    path('book/', views.book, name='book'),
    path('menu/', views.menu, name='menu'),
    path('response/', views.response, name='response'),
    path('form/', views.form, name='form'),
    path('setsession/', views.setsession, name='setsession'),
    path('getsession/', views.getsession, name='getsession'),
    path('clear_session/', views.clear_session, name='clear_session'),
    path('flush_session/', views.flush_session, name='flush_session'),


    #Assignment URLs
    path('login/', views.login_view, name='login'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),

]
